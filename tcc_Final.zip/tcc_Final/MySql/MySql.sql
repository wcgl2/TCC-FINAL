 CREATE TABLE `users`(   
  `id` BIGINT NOT NULL AUTO_INCREMENT,  
  `login` VARCHAR(20) NOT NULL,  
  `password` TINYINT(50) NOT NULL,  
   PRIMARY KEY (`id`)  
 );  

